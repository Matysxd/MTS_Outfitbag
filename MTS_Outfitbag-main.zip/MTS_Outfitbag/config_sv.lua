Config = {}

Config.ItemName = 'outfitbag'