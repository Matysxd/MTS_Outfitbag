ESX = exports["es_extended"]:getSharedObject()

ESX.RegisterUsableItem(Config.ItemName, function(source)
    local xPlayer  = ESX.GetPlayerFromId(source)
        TriggerClientEvent('MTS_Outfitbag:open', source)

end)
