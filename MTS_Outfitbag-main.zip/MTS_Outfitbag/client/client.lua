ESX = nil
local PlayerData = { }

Citizen.CreateThread(function()
    while ESX == nil do
        ESX = exports["es_extended"]:getSharedObject()
        Citizen.Wait(0)
    end
end)

AddEventHandler('onResourceStart', function(resourceName)
    print('MTS_Outfitbag Has started. Version 1.0.0')
  end)
  
  
RegisterNetEvent('MTS_Outfitbag:open')
AddEventHandler('MTS_Outfitbag:open' ,function(playerId, source)
    
if lib.progressBar({
    duration = Times['takeBag'],
    label = Strings['takingBag'],
    useWhileDead = false,
    canCancel = true,
    disable = {
        car = true,
        move = true
    },
    anim = {
        dict = 'anim@heists@ornate_bank@grab_cash',
        clip = 'intro'
    },
}) then else end

if lib.progressBar({
    duration = Times['placeBag'],
    label = Strings['placingBag'],
    useWhileDead = false,
    canCancel = false,
    disable = {
        car = true,
        move = true
    },
    anim = {
        dict = 'amb@medic@standing@tendtodead@base',
        clip = 'base'
    },
    prop = {
        model = `bkr_prop_duffel_bag_01a`,
        pos = vec3(0.13, 0.25, 0.02),
        rot = vec3(10.0, 360.5, 360.5)
    },
}) then  else end

    if lib.progressBar({
        duration = Times['openBag'],
        label = Strings['openBag'],
        useWhileDead = false,
        canCancel = false,
        disable = {
            car = true,
            move = true
        },
        anim = {
            dict = 'mini@repair',
            clip = 'fixing_a_ped'
        },
        prop = {
            model = `prop_nigel_bag_pickup`,
            pos = vec3(0.13, 0.25, 0.02),
            rot = vec3(10.0, 195.0, 195.0)
        },
    }) then

    TriggerEvent('fivem-appearance:browseOutfitsOb')

else end


end)


